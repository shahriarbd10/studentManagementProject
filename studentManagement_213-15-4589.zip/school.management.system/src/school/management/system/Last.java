
package school.management.system;

/**
 *
 * @author Lenovo
 */
public interface Last {
    void finish();
}
